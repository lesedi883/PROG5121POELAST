# QuickChat - Part 3 / Final POE (Store Data and Display Task Report)

This is my final PoE submission for PROG5121 - Programming 1A. It
includes everything from Part 1 (registration and login) and Part 2
(sending messages), plus the Part 3 features: storing messages,
searching them, deleting them, and displaying a report.

## What this app does

Everything from Parts 1 and 2, plus:

1. When the app starts, it loads any messages that were previously
   stored in `stored_messages.json` back into memory.
2. There's a new 4th menu option, **Stored Messages**, with its own
   sub-menu:
   - `a) Display recipients of all stored messages`
   - `b) Display the longest stored message`
   - `c) Search for a message by Message ID`
   - `d) Search for messages by recipient`
   - `e) Delete a message using its Message Hash`
   - `f) Display the full stored messages report`
   - `g) Back to the main menu`
3. Every message the user creates now goes into one of three lists,
   depending on what they chose to do with it: **sent**, **stored**, or
   **disregarded**.

## Project structure

```
QuickChat_Part3/
├── pom.xml
├── README.md
├── src/
│   ├── main/java/
│   │   ├── Login.java     -> Part 1: registration + login logic
│   │   ├── Message.java   -> Parts 2 & 3: message logic, arrays, search/report
│   │   └── Main.java      -> the console app - login, main menu, stored messages sub-menu
│   └── test/java/
│       ├── LoginTest.java
│       ├── MessageTest.java
│       └── StoredMessagesTest.java   -> Part 3 array/search/report tests
```

## How to run it

**In NetBeans / IntelliJ / Eclipse:**
Open the folder as a Maven project (it will download the `org.json`
library automatically) and run `Main.java`.

**From the command line:**
```
mvn compile exec:java -Dexec.mainClass="Main"
```

**To run the unit tests:**
```
mvn test
```

## Decisions I made (worth mentioning in my video)

The Part 3 brief has a couple of places where the instructions and the
test data don't quite line up, so here's how I interpreted things and
why:

- **Search by Message ID**: the brief's own test data for this uses
  Message 4, which was flagged as "Sent", not "Stored". Since the
  feature list puts this under the "Stored Messages" menu, but the
  test itself uses a sent message, I made `searchByMessageID()` search
  through *every* message ever created (sent, stored, or discarded),
  since a message ID should be findable no matter what happened to the
  message.
- **"Sender" of stored messages**: this app only ever has one sender
  (whoever is logged in), so there's no separate "sender" field to
  display - `displayStoredRecipients()` just shows the recipient of
  each stored message.
- The other four Stored Messages features (longest message, search by
  recipient, delete by hash, and the report) all operate on the
  **stored messages array only**, since that matches the feature list
  in section 2 of the Part 3 brief.
- I used the same fixed-message-ID constructor from Part 2 in my Part 3
  tests, so the message hashes and IDs are predictable for testing.

## Still to do (not covered here)

- Automating the tests with GitHub Actions (`.yml` workflow file)
- The voice-over video walking through the code and logic for the
  final PoE
