import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for the Part 3 features: the sent/stored/disregarded
 * arrays, and the "Stored Messages" search, delete and report methods.
 *
 * I used the five test messages from the Part 3 brief to set this up.
 * A couple of notes on decisions I made, because the brief is a little
 * inconsistent in places:
 *
 * - For the "search by Message ID" test, the brief's test data actually
 *   refers to Message 4, which was flagged as "Sent" rather than
 *   "Stored" - so I made searchByMessageID() look through every message
 *   ever created, not just the stored ones, since a message ID should
 *   still be unique and searchable either way.
 * - Message 4's recipient number in the brief ("0838884567") doesn't
 *   actually have the +27 international code, so I didn't run it
 *   through validateRecipientFormat() in this test - I just used the
 *   Message constructor directly, since the point of this test is
 *   checking that the arrays and search methods work, not re-testing
 *   the recipient validation (that's already covered in MessageTest).
 */
public class StoredMessagesTest {

    private Message message1;
    private Message message2;
    private Message message3;
    private Message message4;
    private Message message5;

    @BeforeEach
    public void setUpMessages() {
        Message.resetSentMessages();

        // Test Data Message 1 - Sent
        message1 = new Message("+27834557896", "Did you get the cake?", 0, "1111111111");
        message1.createMessageHash();
        message1.sentMessage("send");

        // Test Data Message 2 - Stored
        message2 = new Message("+27838884567", "Where are you? You are late! I have asked you to be on time.", 1, "2222222222");
        message2.createMessageHash();
        message2.sentMessage("store");

        // Test Data Message 3 - Disregarded
        message3 = new Message("+27834484567", "Yohoooo, I am at your gate.", 2, "3333333333");
        message3.createMessageHash();
        message3.sentMessage("discard");

        // Test Data Message 4 - Sent (recipient as given in the brief, no +27 code)
        message4 = new Message("0838884567", "It is dinner time !", 3, "4444444444");
        message4.createMessageHash();
        message4.sentMessage("send");

        // Test Data Message 5 - Stored
        message5 = new Message("+27838884567", "Ok, I am leaving without you.", 4, "5555555555");
        message5.createMessageHash();
        message5.sentMessage("store");
    }

    @Test
    public void testSentMessagesArray_CorrectlyPopulated() {
        assertEquals(2, Message.getSentMessages().size());
        assertTrue(Message.getSentMessages().contains(message1));
        assertTrue(Message.getSentMessages().contains(message4));
    }

    @Test
    public void testStoredMessagesArray_CorrectlyPopulated() {
        assertEquals(2, Message.getStoredMessages().size());
        assertTrue(Message.getStoredMessages().contains(message2));
        assertTrue(Message.getStoredMessages().contains(message5));
    }

    @Test
    public void testDisregardedMessagesArray_CorrectlyPopulated() {
        assertEquals(1, Message.getDisregardedMessages().size());
        assertTrue(Message.getDisregardedMessages().contains(message3));
    }

    @Test
    public void testDisplayLongestStoredMessage() {
        assertEquals(
            "Where are you? You are late! I have asked you to be on time.",
            Message.displayLongestStoredMessage()
        );
    }

    @Test
    public void testSearchByMessageID() {
        assertEquals(
            "Recipient: 0838884567\nMessage: It is dinner time !",
            Message.searchByMessageID("4444444444")
        );
    }

    @Test
    public void testSearchByRecipient() {
        String result = Message.searchByRecipient("+27838884567");
        assertTrue(result.contains("Where are you? You are late! I have asked you to be on time."));
        assertTrue(result.contains("Ok, I am leaving without you."));
    }

    @Test
    public void testDeleteMessageByHash() {
        String hashToDelete = message2.getMessageHash();
        String result = Message.deleteMessageByHash(hashToDelete);

        assertEquals(
            "Message: \"Where are you? You are late! I have asked you to be on time.\" successfully deleted.",
            result
        );
        assertEquals(1, Message.getStoredMessages().size());
    }

    @Test
    public void testDisplayStoredMessageReport() {
        String report = Message.displayStoredMessageReport();
        assertTrue(report.contains(message2.getMessageHash()));
        assertTrue(report.contains(message5.getMessageHash()));
        assertTrue(report.contains("+27838884567"));
    }
}
