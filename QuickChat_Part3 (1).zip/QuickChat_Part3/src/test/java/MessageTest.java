import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for the Message class.
 *
 * I used the test data from the PROG5121 Part 2 brief, e.g. the message
 * "Hi Mike, can you join us for dinner tonight?" sent to +27718693002.
 *
 * For the message hash test, the brief expects an exact result
 * ("00:0:HITONIGHT"), so I used the second Message constructor to set a
 * fixed message ID starting with "00" instead of a random one - this
 * makes the test result predictable.
 */
public class MessageTest {

    @BeforeEach
    public void clearSentMessages() {
        // Make sure each test starts with a clean list of sent messages.
        Message.resetSentMessages();
    }

    // ---------- checkMessageLength() tests ----------

    @Test
    public void testMessageLength_Success() {
        Message message = new Message("+27718693002", "Hi Mike, can you join us for dinner tonight?", 0);
        assertEquals("Message ready to send.", message.checkMessageLength());
    }

    @Test
    public void testMessageLength_Failure() {
        // Build a message that is 260 characters long, so it is 10 over the limit.
        String longMessage = "A".repeat(260);
        Message message = new Message("+27718693002", longMessage, 0);
        assertEquals("Message exceeds 250 characters by 10; please reduce the size.", message.checkMessageLength());
    }

    // ---------- checkRecipientCell() tests ----------

    @Test
    public void testRecipientCell_CorrectlyFormatted() {
        Message message = new Message("+27718693002", "Hi Mike, can you join us for dinner tonight?", 0);
        assertEquals("Cell phone number successfully captured.", message.checkRecipientCell());
    }

    @Test
    public void testRecipientCell_IncorrectlyFormatted() {
        Message message = new Message("08575975889", "Hi Keegan, did you receive the payment?", 1);
        assertEquals(
            "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.",
            message.checkRecipientCell()
        );
    }

    // ---------- createMessageHash() test ----------

    @Test
    public void testCreateMessageHash() {
        // Fixed ID starting with "00" so the hash comes out exactly as
        // expected in the brief.
        Message message = new Message("+27718693002", "Hi Mike, can you join us for dinner tonight?", 0, "0012345678");
        assertEquals("00:0:HITONIGHT", message.createMessageHash());
    }

    // ---------- checkMessageID() test ----------

    @Test
    public void testMessageID_IsCreated() {
        Message message = new Message("+27718693002", "Hi Mike, can you join us for dinner tonight?", 0);
        assertTrue(message.checkMessageID());
        assertEquals(10, message.getMessageID().length());
    }

    // ---------- sentMessage() tests ----------

    @Test
    public void testSentMessage_Send() {
        Message message = new Message("+27718693002", "Hi Mike, can you join us for dinner tonight?", 0);
        assertEquals("Message successfully sent.", message.sentMessage("send"));
    }

    @Test
    public void testSentMessage_Discard() {
        Message message = new Message("08575975889", "Hi Keegan, did you receive the payment?", 1);
        assertEquals("Press 0 to delete the message.", message.sentMessage("discard"));
    }

    @Test
    public void testSentMessage_Store() {
        Message message = new Message("+27718693002", "Hi Mike, can you join us for dinner tonight?", 0);
        message.createMessageHash();
        assertEquals("Message successfully stored.", message.sentMessage("store"));
    }

    // ---------- returnTotalMessages() test ----------

    @Test
    public void testReturnTotalMessages() {
        Message message1 = new Message("+27718693002", "Hi Mike, can you join us for dinner tonight?", 0);
        message1.sentMessage("send");

        Message message2 = new Message("08575975889", "Hi Keegan, did you receive the payment?", 1);
        message2.sentMessage("discard");

        // Only message1 was actually sent, so the total should be 1.
        assertEquals(1, Message.returnTotalMessages());
    }
}
