import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Message class for QuickChat - Part 2 and Part 3.
 *
 * Each Message object represents one message the user typed in. This
 * class checks the message details, builds the message ID and hash,
 * handles sending/storing/discarding, and (for Part 3) keeps track of
 * every message that has been sent, stored or disregarded so they can
 * be searched, reported on, or deleted.
 *
 * References:
 * - I used the org.json library to build and write/read the JSON file.
 *   Source: stleary. (n.d.) JSON-java library documentation.
 *   Available at: https://github.com/stleary/JSON-java (Accessed: September 2026).
 */
public class Message {

    private String messageID;
    private int messageNumber;
    private String recipient;
    private String messageText;
    private String messageHash;

    // These lists (arrays that can grow) keep track of every message
    // depending on what the user chose to do with it.
    private static List<Message> sentMessages = new ArrayList<>();
    private static List<Message> disregardedMessages = new ArrayList<>();
    private static List<Message> storedMessages = new ArrayList<>();

    // This list keeps every single message ever created, no matter what
    // happened to it - it's what I use to build the Message ID and
    // Message Hash "arrays" that Part 3 asks for.
    private static List<Message> allMessages = new ArrayList<>();

    public Message(String recipient, String messageText, int messageNumber) {
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageNumber = messageNumber;
        this.messageID = generateMessageID();
        allMessages.add(this);
    }

    // This second constructor lets me set a specific message ID instead of a
    // random one - I mainly use this in my unit tests so the message hash
    // comes out the same every time (since the hash uses the first two
    // digits of the ID).
    public Message(String recipient, String messageText, int messageNumber, String fixedMessageID) {
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageNumber = messageNumber;
        this.messageID = fixedMessageID;
        allMessages.add(this);
    }

    // This third constructor is used when we load a message back in from
    // the JSON file - by that point the ID and hash have already been
    // worked out, so we just set them directly instead of generating them.
    public Message(String messageID, String messageHash, String recipient, String messageText) {
        this.messageID = messageID;
        this.messageHash = messageHash;
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageNumber = -1;
        allMessages.add(this);
    }

    // Creates a random 10-digit number to use as the message ID.
    private String generateMessageID() {
        Random random = new Random();
        StringBuilder id = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            id.append(random.nextInt(10));
        }
        return id.toString();
    }

    public String getMessageID() {
        return messageID;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getMessageText() {
        return messageText;
    }

    public String getMessageHash() {
        return messageHash;
    }

    // Checks that the message ID is not more than 10 characters long.
    public boolean checkMessageID() {
        return messageID != null && messageID.length() <= 10;
    }

    // Checks the recipient's cell number - reusing the same +27 rule from Part 1.
    // This is a static helper so Main.java can check the number BEFORE
    // creating a Message object (that way we don't end up with half-built
    // "throwaway" messages cluttering our arrays).
    public static String validateRecipientFormat(String recipient) {
        if (recipient != null && recipient.matches("^\\+27[0-9]{9}$")) {
            return "Cell phone number successfully captured.";
        } else {
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }
    }

    // Checks that a message is not longer than 250 characters. Also a
    // static helper, for the same reason as above.
    public static String validateMessageLength(String messageText) {
        if (messageText.length() > 250) {
            int over = messageText.length() - 250;
            return "Message exceeds 250 characters by " + over + "; please reduce the size.";
        }
        return "Message ready to send.";
    }

    // Instance version of the recipient check, required by the brief's
    // Message class method table - it just reuses the static check above.
    public String checkRecipientCell() {
        return validateRecipientFormat(this.recipient);
    }

    // Instance version of the message length check - reuses the static
    // check above.
    public String checkMessageLength() {
        return validateMessageLength(this.messageText);
    }

    // Builds the message hash: first two digits of the message ID, the
    // message number, and the first + last word of the message (with any
    // punctuation removed) written in capital letters.
    // Example: "00:0:HITONIGHT"
    public String createMessageHash() {
        String idStart = messageID.substring(0, 2);

        String[] words = messageText.trim().split("\\s+");
        String firstWord = words[0].replaceAll("[^a-zA-Z0-9]", "");
        String lastWord = words[words.length - 1].replaceAll("[^a-zA-Z0-9]", "");

        this.messageHash = idStart + ":" + messageNumber + ":" + (firstWord + lastWord).toUpperCase();
        return this.messageHash;
    }

    // Handles what happens when the user chooses to send, discard or store
    // the message, and adds it to the right array. choice should be
    // "send", "discard" or "store".
    public String sentMessage(String choice) {
        if (choice == null) {
            return "Invalid option selected.";
        }

        switch (choice.toLowerCase()) {
            case "send":
                sentMessages.add(this);
                return "Message successfully sent.";
            case "discard":
                disregardedMessages.add(this);
                return "Press 0 to delete the message.";
            case "store":
                storedMessages.add(this);
                storeMessage();
                return "Message successfully stored.";
            default:
                return "Invalid option selected.";
        }
    }

    // Returns all the messages that have been sent so far, nicely formatted.
    public static String printMessages() {
        if (sentMessages.isEmpty()) {
            return "No messages have been sent yet.";
        }

        StringBuilder allSent = new StringBuilder();
        for (Message message : sentMessages) {
            allSent.append("Message ID: ").append(message.getMessageID()).append("\n");
            allSent.append("Message Hash: ").append(message.getMessageHash()).append("\n");
            allSent.append("Recipient: ").append(message.getRecipient()).append("\n");
            allSent.append("Message: ").append(message.getMessageText()).append("\n");
            allSent.append("-----------------------------\n");
        }
        return allSent.toString();
    }

    // Returns how many messages have been sent so far.
    public static int returnTotalMessages() {
        return sentMessages.size();
    }

    // Only used by the tests, so each test starts with a clean slate.
    public static void resetSentMessages() {
        sentMessages.clear();
        disregardedMessages.clear();
        storedMessages.clear();
        allMessages.clear();
    }

    // ------------------------------------------------------------------
    // Part 3: arrays and the "Stored Messages" menu features
    // ------------------------------------------------------------------

    public static List<Message> getSentMessages() {
        return sentMessages;
    }

    public static List<Message> getDisregardedMessages() {
        return disregardedMessages;
    }

    public static List<Message> getStoredMessages() {
        return storedMessages;
    }

    // Returns an array of every message hash that has been generated so far.
    public static String[] getAllMessageHashes() {
        List<String> hashes = new ArrayList<>();
        for (Message message : allMessages) {
            if (message.getMessageHash() != null) {
                hashes.add(message.getMessageHash());
            }
        }
        return hashes.toArray(new String[0]);
    }

    // Returns an array of every message ID that has been generated so far.
    public static String[] getAllMessageIDs() {
        List<String> ids = new ArrayList<>();
        for (Message message : allMessages) {
            ids.add(message.getMessageID());
        }
        return ids.toArray(new String[0]);
    }

    // 2a) Display the recipient of every stored message.
    // Note: this app only ever has one sender (whoever is logged in), so
    // there's no separate "sender" field to show - I just show the
    // recipient for each stored message.
    public static String displayStoredRecipients() {
        if (storedMessages.isEmpty()) {
            return "There are no stored messages.";
        }

        StringBuilder result = new StringBuilder();
        for (Message message : storedMessages) {
            result.append("Recipient: ").append(message.getRecipient()).append("\n");
        }
        return result.toString();
    }

    // 2b) Display the longest message out of all the stored messages.
    public static String displayLongestStoredMessage() {
        if (storedMessages.isEmpty()) {
            return "There are no stored messages.";
        }

        Message longest = storedMessages.get(0);
        for (Message message : storedMessages) {
            if (message.getMessageText().length() > longest.getMessageText().length()) {
                longest = message;
            }
        }
        return longest.getMessageText();
    }

    // 2c) Search for a message ID and display its recipient and message.
    // Note: I search through every message that has ever been created here
    // (not just the stored ones) because a message ID should be unique no
    // matter what the user chose to do with that message.
    public static String searchByMessageID(String messageID) {
        for (Message message : allMessages) {
            if (message.getMessageID().equals(messageID)) {
                return "Recipient: " + message.getRecipient() + "\nMessage: " + message.getMessageText();
            }
        }
        return "No message was found with that ID.";
    }

    // 2d) Search for all the stored messages sent to a particular recipient.
    public static String searchByRecipient(String recipient) {
        StringBuilder result = new StringBuilder();
        for (Message message : storedMessages) {
            if (message.getRecipient().equals(recipient)) {
                result.append(message.getMessageText()).append("\n");
            }
        }

        if (result.length() == 0) {
            return "No stored messages were found for that recipient.";
        }
        return result.toString();
    }

    // 2e) Delete a stored message using its message hash.
    public static String deleteMessageByHash(String hash) {
        for (int i = 0; i < storedMessages.size(); i++) {
            Message message = storedMessages.get(i);
            if (hash.equals(message.getMessageHash())) {
                storedMessages.remove(i);
                return "Message: \"" + message.getMessageText() + "\" successfully deleted.";
            }
        }
        return "No stored message was found with that hash.";
    }

    // 2f) Display a report with the full details of every stored message.
    public static String displayStoredMessageReport() {
        if (storedMessages.isEmpty()) {
            return "There are no stored messages to report on.";
        }

        StringBuilder report = new StringBuilder();
        report.append("===== Stored Messages Report =====\n");
        for (Message message : storedMessages) {
            report.append("Message Hash: ").append(message.getMessageHash()).append("\n");
            report.append("Recipient: ").append(message.getRecipient()).append("\n");
            report.append("Message: ").append(message.getMessageText()).append("\n");
            report.append("-----------------------------\n");
        }
        return report.toString();
    }

    // Loads any previously stored messages from stored_messages.json back
    // into the storedMessages array. I call this once when the app starts.
    public static void loadStoredMessagesFromFile() {
        File file = new File("stored_messages.json");
        if (!file.exists()) {
            return;
        }

        try {
            String content = new String(Files.readAllBytes(file.toPath()));
            if (content.isBlank()) {
                return;
            }

            JSONArray messagesArray = new JSONArray(content);
            for (int i = 0; i < messagesArray.length(); i++) {
                JSONObject obj = messagesArray.getJSONObject(i);
                Message loadedMessage = new Message(
                        obj.getString("messageID"),
                        obj.getString("messageHash"),
                        obj.getString("recipient"),
                        obj.getString("message")
                );
                storedMessages.add(loadedMessage);
            }
        } catch (IOException e) {
            System.out.println("Something went wrong while loading stored messages: " + e.getMessage());
        }
    }

    // Saves this message into the JSON file, adding it to whatever is
    // already in there.
    private void storeMessage() {
        try {
            File file = new File("stored_messages.json");
            JSONArray messagesArray;

            if (file.exists()) {
                String content = new String(Files.readAllBytes(file.toPath()));
                messagesArray = content.isBlank() ? new JSONArray() : new JSONArray(content);
            } else {
                messagesArray = new JSONArray();
            }

            JSONObject messageObject = new JSONObject();
            messageObject.put("messageID", this.messageID);
            messageObject.put("messageHash", this.messageHash);
            messageObject.put("recipient", this.recipient);
            messageObject.put("message", this.messageText);

            messagesArray.put(messageObject);

            try (FileWriter writer = new FileWriter(file)) {
                writer.write(messagesArray.toString(4));
            }

        } catch (IOException e) {
            System.out.println("Something went wrong while saving the message: " + e.getMessage());
        }
    }
}
