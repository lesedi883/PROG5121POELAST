import java.util.Scanner;

/**
 * QuickChat - Part 3: Store Data and Display Task Report
 *
 * This builds on Parts 1 and 2. The user registers, logs in, can send
 * messages, and now there is also a fourth menu option, "Stored
 * Messages", which lets them look through, search and delete the
 * messages they chose to store instead of sending.
 *
 * No GUI is used, as required by the brief - everything runs through
 * the console using Scanner.
 */
public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Load in any messages that were stored in a previous run of the app.
        Message.loadStoredMessagesFromFile();

        Login login = registerUser(scanner);
        boolean loggedIn = logInUser(scanner, login);

        if (!loggedIn) {
            System.out.println("We couldn't log you in, so we can't continue. Goodbye.");
            scanner.close();
            return;
        }

        System.out.println("\nWelcome to QuickChat.");

        boolean alreadySentMessages = false;
        boolean quit = false;

        while (!quit) {
            System.out.println("\n===== QuickChat Menu =====");
            System.out.println("1) Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Quit");
            System.out.println("4) Stored Messages");
            System.out.print("Choose an option: ");
            String option = scanner.nextLine();

            switch (option) {
                case "1":
                    if (alreadySentMessages) {
                        System.out.println("You have already entered your messages for this session.");
                    } else {
                        sendMessages(scanner);
                        alreadySentMessages = true;
                    }
                    break;
                case "2":
                    System.out.println("Coming Soon.");
                    break;
                case "3":
                    quit = true;
                    System.out.println("\nTotal messages sent: " + Message.returnTotalMessages());
                    System.out.println("Thanks for using QuickChat. Goodbye!");
                    break;
                case "4":
                    storedMessagesMenu(scanner);
                    break;
                default:
                    System.out.println("That's not a valid option, please choose 1, 2, 3 or 4.");
            }
        }

        scanner.close();
    }

    // Handles registering a new user, looping until the details are valid.
    private static Login registerUser(Scanner scanner) {
        System.out.println("===================================");
        System.out.println(" Welcome to QuickChat Registration ");
        System.out.println("===================================");

        Login login = null;
        boolean registeredSuccessfully = false;

        while (!registeredSuccessfully) {
            System.out.print("Enter a username (must contain an underscore and be 5 characters or less): ");
            String username = scanner.nextLine();

            System.out.print("Enter a password (8+ characters, a capital letter, a number and a special character): ");
            String password = scanner.nextLine();

            System.out.print("Enter your first name: ");
            String firstName = scanner.nextLine();

            System.out.print("Enter your last name: ");
            String lastName = scanner.nextLine();

            System.out.print("Enter your South African cell phone number (e.g. +27831234567): ");
            String cellNumber = scanner.nextLine();

            login = new Login(username, password, cellNumber, firstName, lastName);

            String registerMessage = login.registerUser();
            System.out.println(registerMessage);

            if (registerMessage.contains("not correctly formatted")) {
                System.out.println("Please try registering again.\n");
                continue;
            }

            if (login.checkCellPhoneNumber(cellNumber)) {
                System.out.println("Cell phone number successfully added.");
            } else {
                System.out.println("Cell phone number incorrectly formatted or does not contain international code.");
                System.out.println("Please try registering again.\n");
                continue;
            }

            registeredSuccessfully = true;
        }

        return login;
    }

    // Handles logging the user back in with the account they just made.
    private static boolean logInUser(Scanner scanner, Login login) {
        System.out.println("\nYou are registered! Now let's log you in.");
        System.out.println("===================================");

        System.out.print("Enter your username: ");
        String loginUsername = scanner.nextLine();

        System.out.print("Enter your password: ");
        String loginPassword = scanner.nextLine();

        boolean loginSuccessful = login.loginUser(loginUsername, loginPassword);
        System.out.println(login.returnLoginStatus(loginSuccessful));

        return loginSuccessful;
    }

    // Lets the user enter and send the number of messages they asked for.
    private static void sendMessages(Scanner scanner) {
        int numberOfMessages = 0;

        while (numberOfMessages <= 0) {
            System.out.print("How many messages would you like to enter? ");
            try {
                numberOfMessages = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a whole number.");
            }
        }

        // A for loop is used here so we enter exactly the number of
        // messages the user asked for - this also gives us our loop
        // counter, which we use as the message number in the hash.
        for (int i = 0; i < numberOfMessages; i++) {

            System.out.println("\n--- Message " + (i + 1) + " of " + numberOfMessages + " ---");

            // Keep asking for the recipient number until it's valid. We
            // check it BEFORE creating the Message object so we don't end
            // up with half-finished messages sitting in our arrays.
            String recipient;
            while (true) {
                System.out.print("Enter the recipient's cell number (e.g. +27831234567): ");
                recipient = scanner.nextLine();

                String recipientMessage = Message.validateRecipientFormat(recipient);
                System.out.println(recipientMessage);

                if (recipientMessage.startsWith("Cell phone number successfully")) {
                    break;
                }
            }

            // Keep asking for the message text until it's short enough.
            String messageText;
            while (true) {
                System.out.print("Enter your message (250 characters or less): ");
                messageText = scanner.nextLine();

                String lengthMessage = Message.validateMessageLength(messageText);
                System.out.println(lengthMessage);

                if (lengthMessage.equals("Message ready to send.")) {
                    break;
                }
            }

            Message message = new Message(recipient, messageText, i);
            message.createMessageHash();

            System.out.print("What would you like to do? (1 = Send, 2 = Disregard, 3 = Store): ");
            String choice = scanner.nextLine();

            String action;
            switch (choice) {
                case "1":
                    action = "send";
                    break;
                case "2":
                    action = "discard";
                    break;
                case "3":
                    action = "store";
                    break;
                default:
                    action = "";
            }

            String resultMessage = message.sentMessage(action);
            System.out.println(resultMessage);

            if (action.equals("send")) {
                System.out.println("Message ID: " + message.getMessageID());
                System.out.println("Message Hash: " + message.getMessageHash());
                System.out.println("Recipient: " + message.getRecipient());
                System.out.println("Message: " + message.getMessageText());
            }
        }

        System.out.println("\nAll done! You entered " + numberOfMessages + " message(s).");
    }

    // The "Stored Messages" sub-menu added in Part 3.
    private static void storedMessagesMenu(Scanner scanner) {
        boolean back = false;

        while (!back) {
            System.out.println("\n----- Stored Messages -----");
            System.out.println("a) Display recipients of all stored messages");
            System.out.println("b) Display the longest stored message");
            System.out.println("c) Search for a message by Message ID");
            System.out.println("d) Search for messages by recipient");
            System.out.println("e) Delete a message using its Message Hash");
            System.out.println("f) Display the full stored messages report");
            System.out.println("g) Back to the main menu");
            System.out.print("Choose an option: ");
            String option = scanner.nextLine();

            switch (option.toLowerCase()) {
                case "a":
                    System.out.println(Message.displayStoredRecipients());
                    break;
                case "b":
                    System.out.println(Message.displayLongestStoredMessage());
                    break;
                case "c":
                    System.out.print("Enter the Message ID to search for: ");
                    String messageID = scanner.nextLine();
                    System.out.println(Message.searchByMessageID(messageID));
                    break;
                case "d":
                    System.out.print("Enter the recipient's number to search for: ");
                    String recipient = scanner.nextLine();
                    System.out.println(Message.searchByRecipient(recipient));
                    break;
                case "e":
                    System.out.print("Enter the Message Hash of the message to delete: ");
                    String hash = scanner.nextLine();
                    System.out.println(Message.deleteMessageByHash(hash));
                    break;
                case "f":
                    System.out.println(Message.displayStoredMessageReport());
                    break;
                case "g":
                    back = true;
                    break;
                default:
                    System.out.println("That's not a valid option, please choose a, b, c, d, e, f or g.");
            }
        }
    }
}
